﻿Public Class Form1

    '------------------------------------------------------------
    '- File Name : Form1.vb                                     -
    '- Part of Project: Tic Tac Toe Stuff Yo                    -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the code for the main form of the     -
    '- Tic Tac Toe game.                                        -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- This program is designed to allow the user to play a     -
    '- game of Tic Tac Toe against another player...            -
    '- or yourself....                                          -
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- symbolBeingDragged - The symbol being dragged.           -
    '- currentSymbol - The current symbol.                      -
    '------------------------------------------------------------


    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------
    Private symbolBeingDragged As String = ""
    Private currentSymbol As String = "X"


    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    '------------------------------------------------------------
    '- Subprogram Name: Form1_Load                              -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when the form is loaded. It    -
    '- sets up the form and the event handlers for the picture  -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the event.               -
    '- e - The event arguments.                                 -       
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '------------------------------------------------------------
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' For each picture box, enable allow drop and set the handlers
        ' for the drag enter and drag drop events.
        For Each PB As PictureBox In Me.Controls.OfType(Of PictureBox)()
            PB.AllowDrop = True
            AddHandler PB.MouseMove, AddressOf PBs_MouseMove
            AddHandler PB.DragEnter, AddressOf PBs_DragEnter
            AddHandler PB.DragDrop, AddressOf PBs_DragDrop
            AddHandler PB.DragOver, AddressOf PBs_DragOver
        Next
        SetActiveSymbol()
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: SetActiveSymbol                         -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine sets the active symbol.                  -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- None.                                                    -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- None.                                                    -
    '------------------------------------------------------------
    Private Sub SetActiveSymbol()
        ' Set the background color for the active symbol
        If currentSymbol = "X" Then
            currentSymbol = "O"
            pbX.BackColor = Color.LightBlue
            pbO.BackColor = Color.Transparent
        Else
            currentSymbol = "X"
            pbX.BackColor = Color.Transparent
            pbO.BackColor = Color.LightBlue
        End If
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: PBs_MouseMove                           -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when a picture box is being    -
    '- moved by the mouse. It sets the symbol being dragged to  -
    '- the current symbol if it's the correct player's turn,    -
    '- and allows the drag-and-drop operation.                  -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the event.               -
    '- e - The event arguments.                                 -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '------------------------------------------------------------
    Private Sub PBs_MouseMove(ByVal sender As Object, e As MouseEventArgs)
        Dim PB As PictureBox = DirectCast(sender, PictureBox)
        Console.WriteLine(PB.Name & " MOUSE MOVE")

        If Not PB.Name.Contains("pbGrid") Then
            If PB.BackgroundImage IsNot Nothing AndAlso e.Button = MouseButtons.Left AndAlso If(PB.Name = "pbX", "X", "O") IsNot currentSymbol Then
                symbolBeingDragged = currentSymbol
                PB.DoDragDrop(PB.BackgroundImage, DragDropEffects.Copy)
            End If
        End If
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: PBs_DragEnter                           -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when a picture box is entered  -
    '- by the dragged object. It allows the drop operation.     -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the event.               -
    '- e - The event arguments.                                 -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '------------------------------------------------------------
    Private Sub PBs_DragEnter(ByVal sender As Object, e As DragEventArgs)
        Dim PB As PictureBox = DirectCast(sender, PictureBox)
        Console.WriteLine(PB.Name & " DRAG ENTER")
        If e.Data.GetDataPresent(DataFormats.Bitmap) AndAlso PB.BackgroundImage Is Nothing AndAlso (PB.Name <> "pbX" AndAlso PB.Name <> "pbO") Then
            If symbolBeingDragged <> PB.Name Then
                e.Effect = DragDropEffects.Copy
            Else
                e.Effect = DragDropEffects.None
            End If
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: PBs_DragDrop                            -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when a picture box is dropped  -
    '- by the dragged object. It places the symbol on the board, -
    '- and checks for a win condition.                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the event.               -
    '- e - The event arguments.                                 -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '- position - The position of the symbol on the board.       -
    '------------------------------------------------------------
    Private Sub PBs_DragOver(ByVal sender As Object, e As DragEventArgs)
        Dim PB As PictureBox = DirectCast(sender, PictureBox)
        Console.WriteLine(PB.Name & " DRAG OVER")
        If PB.Name.StartsWith("pbGrid") Then
            If e.Data.GetDataPresent(DataFormats.Bitmap) AndAlso PB.BackgroundImage Is Nothing AndAlso (PB.Name <> "pbX" AndAlso PB.Name <> "pbO") Then
                If symbolBeingDragged <> PB.Name Then
                    e.Effect = DragDropEffects.Copy
                Else
                    e.Effect = DragDropEffects.None
                End If
            Else
                e.Effect = DragDropEffects.None
            End If
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: PBs_DragDrop                            -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine is called when a picture box is dropped  -
    '- by the dragged object. It places the symbol on the board, -
    '- and checks for a win condition.                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the event.               -
    '- e - The event arguments.                                 -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '------------------------------------------------------------
    Private Sub PBs_DragDrop(ByVal sender As Object, e As DragEventArgs)
        Dim PB As PictureBox = DirectCast(sender, PictureBox)
        Console.WriteLine(PB.Name & " DRAG DROP")
        PB.BackgroundImage = CType(e.Data.GetData(DataFormats.Bitmap), Image)
        ' Set the appropriate text in the box.
        If symbolBeingDragged = "X" Then
            PB.Tag = "X"
        Else
            PB.Tag = "O"
        End If
        ' Set the active symbol
        SetActiveSymbol()

        ' Check for a win or tie.
        CheckForWinnerOrTie()
    End Sub


    '------------------------------------------------------------
    '- Subprogram Name: CheckForWinnerOrTie                     -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine checks for a winner or tie.              -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- None.                                                    -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- combination - A combination of boxes that could win.      -
    '- winningCombinations - All possible winning combinations. -
    '------------------------------------------------------------
    Private Sub CheckForWinnerOrTie()
        Dim winningCombinations As Integer()() = {
            New Integer() {1, 2, 3}, ' horizontal rows
            New Integer() {4, 5, 6},
            New Integer() {7, 8, 9},
            New Integer() {1, 4, 7}, ' vertical columns
            New Integer() {2, 5, 8},
            New Integer() {3, 6, 9},
            New Integer() {1, 5, 9}, ' diagonals
            New Integer() {3, 5, 7}
        }

        For Each combination In winningCombinations
            Dim tag1 As String = CType(Me.Controls("pbGrid" & combination(0)), PictureBox).Tag
            Dim tag2 As String = CType(Me.Controls("pbGrid" & combination(1)), PictureBox).Tag
            Dim tag3 As String = CType(Me.Controls("pbGrid" & combination(2)), PictureBox).Tag

            If tag1 <> "" AndAlso tag1 = tag2 AndAlso tag2 = tag3 Then

                ' Mark the winning combination with a green background.
                CType(Me.Controls("pbGrid" & combination(0)), PictureBox).BackColor = Color.Green
                CType(Me.Controls("pbGrid" & combination(1)), PictureBox).BackColor = Color.Green
                CType(Me.Controls("pbGrid" & combination(2)), PictureBox).BackColor = Color.Green


                lblWinner.Visible = True
                lblWinner.Text = " Game goes to " & If(tag1 = "X", "O", "X")
                ' Disable the picture boxes.
                For Each PB As PictureBox In Me.Controls.OfType(Of PictureBox)()
                    PB.Enabled = False
                Next
                Exit Sub
            End If

            ' No winner found, check for tie.
            If Not Me.Controls.OfType(Of PictureBox)().Any(Function(PB) PB.BackgroundImage Is Nothing) Then
                lblWinner.Visible = True
                lblWinner.Text = "Game is tied"
                ' Disable the picture boxes.
                For Each Box In Me.Controls.OfType(Of PictureBox)()
                    Box.Enabled = False
                Next
            End If
        Next
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: ResetBoard                              -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine resets the board.                        -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- None.                                                    -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- PB - A picture box.                                      -
    '------------------------------------------------------------
    Private Sub ResetBoard()
        ' Hide the winner label
        lblWinner.Visible = False
        ' Clear the picture boxes
        For Each PB As PictureBox In Me.Controls.OfType(Of PictureBox)()
            ' Ignore the X and O picture boxes.
            If PB.Name = "pbX" OrElse PB.Name = "pbO" Then
                PB.Enabled = True
                PB.Tag = Nothing
                Continue For
            End If
            PB.BackgroundImage = Nothing
            PB.Tag = Nothing
            PB.Enabled = True
            PB.BackColor = Color.Transparent
        Next

        ' START NOTE
        ' I did not reset the active symbol because I feel like
        ' its fairly normal to switch who goes first between games
        ' and to not have the same person starting every game
        ' would be more realistic.
        ' END NOTE
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: lblResetBoard_Click                     -
    '------------------------------------------------------------
    '- Written By: Justin Kruskie                               -
    '- Written On: March 13, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine resets the board.                        -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- None.                                                    -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- None.                                                    -
    '------------------------------------------------------------
    Private Sub lblResetBoard_Click(sender As Object, e As EventArgs) Handles lblResetBoard.Click
        ' Reset the board and winner
        ResetBoard()
    End Sub

End Class
