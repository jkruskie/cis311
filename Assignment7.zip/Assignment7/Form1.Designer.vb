﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pbO = New System.Windows.Forms.PictureBox()
        Me.pbX = New System.Windows.Forms.PictureBox()
        Me.pbGrid6 = New System.Windows.Forms.PictureBox()
        Me.pbGrid4 = New System.Windows.Forms.PictureBox()
        Me.pbGrid7 = New System.Windows.Forms.PictureBox()
        Me.pbGrid3 = New System.Windows.Forms.PictureBox()
        Me.pbGrid8 = New System.Windows.Forms.PictureBox()
        Me.pbGrid2 = New System.Windows.Forms.PictureBox()
        Me.pbGrid9 = New System.Windows.Forms.PictureBox()
        Me.pbGrid1 = New System.Windows.Forms.PictureBox()
        Me.pbGrid5 = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblWinner = New System.Windows.Forms.Label()
        Me.lblResetBoard = New System.Windows.Forms.Label()
        CType(Me.pbO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbGrid5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'pbO
        '
        Me.pbO.BackgroundImage = Global.Assignment7.My.Resources.Resources.circle_outline
        Me.pbO.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbO.Dock = System.Windows.Forms.DockStyle.Right
        Me.pbO.Location = New System.Drawing.Point(679, 0)
        Me.pbO.Name = "pbO"
        Me.pbO.Size = New System.Drawing.Size(114, 547)
        Me.pbO.TabIndex = 20
        Me.pbO.TabStop = False
        '
        'pbX
        '
        Me.pbX.BackgroundImage = Global.Assignment7.My.Resources.Resources.close
        Me.pbX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbX.Dock = System.Windows.Forms.DockStyle.Left
        Me.pbX.Location = New System.Drawing.Point(0, 0)
        Me.pbX.Name = "pbX"
        Me.pbX.Size = New System.Drawing.Size(114, 547)
        Me.pbX.TabIndex = 30
        Me.pbX.TabStop = False
        '
        'pbGrid6
        '
        Me.pbGrid6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid6.Location = New System.Drawing.Point(492, 158)
        Me.pbGrid6.Name = "pbGrid6"
        Me.pbGrid6.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid6.TabIndex = 26
        Me.pbGrid6.TabStop = False
        '
        'pbGrid4
        '
        Me.pbGrid4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid4.Location = New System.Drawing.Point(120, 158)
        Me.pbGrid4.Name = "pbGrid4"
        Me.pbGrid4.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid4.TabIndex = 24
        Me.pbGrid4.TabStop = False
        '
        'pbGrid7
        '
        Me.pbGrid7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid7.Location = New System.Drawing.Point(120, 304)
        Me.pbGrid7.Name = "pbGrid7"
        Me.pbGrid7.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid7.TabIndex = 27
        Me.pbGrid7.TabStop = False
        '
        'pbGrid3
        '
        Me.pbGrid3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid3.Location = New System.Drawing.Point(492, 12)
        Me.pbGrid3.Name = "pbGrid3"
        Me.pbGrid3.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid3.TabIndex = 23
        Me.pbGrid3.TabStop = False
        '
        'pbGrid8
        '
        Me.pbGrid8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid8.Location = New System.Drawing.Point(306, 304)
        Me.pbGrid8.Name = "pbGrid8"
        Me.pbGrid8.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid8.TabIndex = 28
        Me.pbGrid8.TabStop = False
        '
        'pbGrid2
        '
        Me.pbGrid2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid2.Location = New System.Drawing.Point(306, 12)
        Me.pbGrid2.Name = "pbGrid2"
        Me.pbGrid2.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid2.TabIndex = 22
        Me.pbGrid2.TabStop = False
        '
        'pbGrid9
        '
        Me.pbGrid9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid9.Location = New System.Drawing.Point(492, 304)
        Me.pbGrid9.Name = "pbGrid9"
        Me.pbGrid9.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid9.TabIndex = 29
        Me.pbGrid9.TabStop = False
        '
        'pbGrid1
        '
        Me.pbGrid1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid1.Location = New System.Drawing.Point(120, 12)
        Me.pbGrid1.Name = "pbGrid1"
        Me.pbGrid1.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid1.TabIndex = 21
        Me.pbGrid1.TabStop = False
        '
        'pbGrid5
        '
        Me.pbGrid5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbGrid5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pbGrid5.Location = New System.Drawing.Point(306, 158)
        Me.pbGrid5.Name = "pbGrid5"
        Me.pbGrid5.Size = New System.Drawing.Size(180, 140)
        Me.pbGrid5.TabIndex = 25
        Me.pbGrid5.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.lblWinner)
        Me.Panel2.Controls.Add(Me.lblResetBoard)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(114, 447)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(565, 100)
        Me.Panel2.TabIndex = 33
        '
        'lblWinner
        '
        Me.lblWinner.AutoSize = True
        Me.lblWinner.Enabled = False
        Me.lblWinner.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblWinner.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWinner.ForeColor = System.Drawing.Color.Black
        Me.lblWinner.Location = New System.Drawing.Point(137, 16)
        Me.lblWinner.Name = "lblWinner"
        Me.lblWinner.Size = New System.Drawing.Size(287, 42)
        Me.lblWinner.TabIndex = 18
        Me.lblWinner.Text = "Game goes to X"
        Me.lblWinner.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblWinner.Visible = False
        '
        'lblResetBoard
        '
        Me.lblResetBoard.AutoSize = True
        Me.lblResetBoard.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblResetBoard.Location = New System.Drawing.Point(234, 71)
        Me.lblResetBoard.Name = "lblResetBoard"
        Me.lblResetBoard.Size = New System.Drawing.Size(99, 20)
        Me.lblResetBoard.TabIndex = 17
        Me.lblResetBoard.Text = "Reset Board"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(793, 547)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.pbX)
        Me.Controls.Add(Me.pbGrid9)
        Me.Controls.Add(Me.pbGrid8)
        Me.Controls.Add(Me.pbGrid7)
        Me.Controls.Add(Me.pbGrid6)
        Me.Controls.Add(Me.pbGrid5)
        Me.Controls.Add(Me.pbGrid4)
        Me.Controls.Add(Me.pbGrid3)
        Me.Controls.Add(Me.pbGrid2)
        Me.Controls.Add(Me.pbGrid1)
        Me.Controls.Add(Me.pbO)
        Me.Name = "Form1"
        Me.Text = "Tic-Tac-Toe-Yo-Yo"
        CType(Me.pbO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbGrid5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pbO As PictureBox
    Friend WithEvents pbX As PictureBox
    Friend WithEvents pbGrid6 As PictureBox
    Friend WithEvents pbGrid4 As PictureBox
    Friend WithEvents pbGrid7 As PictureBox
    Friend WithEvents pbGrid3 As PictureBox
    Friend WithEvents pbGrid8 As PictureBox
    Friend WithEvents pbGrid2 As PictureBox
    Friend WithEvents pbGrid9 As PictureBox
    Friend WithEvents pbGrid1 As PictureBox
    Friend WithEvents pbGrid5 As PictureBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents lblWinner As Label
    Friend WithEvents lblResetBoard As Label
End Class
