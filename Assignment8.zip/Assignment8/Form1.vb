﻿Imports System.Data.SqlClient
Public Class Form1

    '------------------------------------------------------------
    '- File Name : Form1.vb                                     -
    '- Part of Project: Main Form                               -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- File Purpose:                                            -
    '-                                                          -
    '- This file contains the main form for the entire appli-   -
    '- cation. This form will allow the user to view different  -
    '- colleges and their degrees. The user will also be able to-
    '- add, edit, and delete colleges and degrees.              -
    '------------------------------------------------------------
    '- Program Purpose:                                         -
    '-                                                          -
    '- The purpose of this program is to handle the data for a  -
    '- college database. The user will be able to view, add,    -
    '- edit, and delete colleges and degrees.                   -
    '------------------------------------------------------------
    '- Global Variable Dictionary (alphabetically):             -
    '- DBAdaptColleges - The data adapter for the colleges      -
    '- DBAdaptDegrees - The data adapter for the degrees        -
    '- dsColleges - The data set for the colleges               -
    '- dsDegrees - The data set for the degrees                 -
    '- strDBName - The name of the database                     -
    '- strConnString - The connection string for the database   -
    '- sqlConn - The connection to the database                 -
    '------------------------------------------------------------

    '---------------------------------------------------------------------------------------
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '--- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES --- GLOBAL VARIABLES ---
    '---------------------------------------------------------------------------------------
    Dim DBAdaptColleges As SqlDataAdapter
    Dim DBAdaptDegrees As SqlDataAdapter
    Dim dsColleges As New DataSet
    Dim dsDegrees As New DataSet
    Public strDBName As String = My.Application.Info.DirectoryPath & "\CollegeInfo.mdf"
    Public strConnString As String = "Server=(localdb)\MSSQLLocalDB;" &
             "Database=CollegeInfo;Integrated Security=SSPI;AttachDbFileName=" &
             strDBName
    Dim sqlConn As New SqlConnection(strConnString)

    '-----------------------------------------------------------------------------------
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '--- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS --- SUBPROGRAMS ---
    '-----------------------------------------------------------------------------------

    '------------------------------------------------------------
    '- Subprogram Name: Form1_Load                              -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine will load the form and set the data      -
    '- bindings for the text boxes.                             -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- strSQL - The SQL statement to get the colleges           -
    '------------------------------------------------------------
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSQL As String
        strSQL = "Select * from Colleges"
        DBAdaptColleges = New SqlDataAdapter(strSQL, strConnString)
        DBAdaptColleges.Fill(dsColleges, "Colleges")
        txtID.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.Id"))
        txtName.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.CollegeName"))
        txtStreet.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.Address"))
        txtCity.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.City"))
        txtState.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.State"))
        txtZip.DataBindings.Add(New Binding("Text", dsColleges, "Colleges.ZipCode"))
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnSave_Click                           -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine saves the current college information    -
    '- to the database and updates the form controls.           -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        BindingContext(dsColleges, "Colleges").EndCurrentEdit()
        sqlConn.Open()
        DBAdaptColleges.Update(dsColleges, "Colleges")
        sqlConn.Close()
        dsColleges.AcceptChanges()
        flipTxtEnabled()
        flipBtnSaveCancelShow()
        flipBtnNavigation()
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnCancel_Click                         -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine cancels the current edit, reverts any    -
    '- changes made to the college information, and updates     -
    '- the form controls.                                       -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        BindingContext(dsColleges, "Colleges").CancelCurrentEdit()
        dsColleges.RejectChanges()
        BindingContext(dsColleges, "Colleges").Position =
            BindingContext(dsColleges, "Colleges").Count - 1
        flipTxtEnabled()
        flipBtnSaveCancelShow()
        flipBtnNavigation()
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnLast_Click                           -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine navigates to the last college record     -
    '- in the dataset.                                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        BindingContext(dsColleges, "Colleges").Position =
                        (BindingContext(dsColleges, "Colleges").Count - 1)
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnNext_Click                           -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine navigates to the next college record     -
    '- in the dataset.                                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        BindingContext(dsColleges, "Colleges").Position =
                       (BindingContext(dsColleges, "Colleges").Position + 1)
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnFirst_Click                          -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine navigates to the first college record    -
    '- in the dataset.                                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        BindingContext(dsColleges, "Colleges").Position = 0
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnPrevious_Click                       -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine navigates to the previous college record -
    '- in the dataset.                                          -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btPrevious.Click
        BindingContext(dsColleges, "Colleges").Position =
                       (BindingContext(dsColleges, "Colleges").Position - 1)
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnAdd_Click                            -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine adds a new college record to the dataset.-
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- cmdBuilder - The command builder object                  -
    '------------------------------------------------------------
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim cmdBuilder As SqlCommandBuilder
        cmdBuilder = New SqlCommandBuilder(DBAdaptColleges)
        DBAdaptColleges.InsertCommand = cmdBuilder.GetInsertCommand
        flipTxtEnabled()
        flipBtnSaveCancelShow()
        flipBtnNavigation()
        BindingContext(dsColleges, "Colleges").AddNew()
        txtID.Text = GetNextAvailableID().ToString()
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnDelete_Click                         -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine deletes the current college record from  -
    '- the dataset.                                             -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- cmdBuilder - The command builder object                  -
    '------------------------------------------------------------
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim cmdBuilder As SqlCommandBuilder
        cmdBuilder = New SqlCommandBuilder(DBAdaptColleges)
        DBAdaptColleges.InsertCommand = cmdBuilder.GetDeleteCommand
        If MessageBox.Show("Are you sure you want to delete?", "Delete Record", MessageBoxButtons.YesNo) _
                        = DialogResult.Yes Then
            BindingContext(dsColleges, "Colleges").RemoveAt(BindingContext(dsColleges, "Colleges").Position)
            dsColleges.AcceptChanges()
        End If
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnUpdate_Click                           -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine updates the current college record to the-
    '- database.                                                -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- cmdBuilder - The command builder object                  -
    '------------------------------------------------------------
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim cmdBuilder As SqlCommandBuilder
        cmdBuilder = New SqlCommandBuilder(DBAdaptColleges)
        DBAdaptColleges.InsertCommand = cmdBuilder.GetUpdateCommand
        flipTxtEnabled()
        flipBtnSaveCancelShow()
        flipBtnNavigation()
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: flipTxtEnabled                          -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine flips the enabled property of the text   -
    '- boxes in the group box.                                  -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- textBox - The text box object                            -
    '- textBoxes - The collection of text box objects           -
    '------------------------------------------------------------
    Private Sub flipTxtEnabled()
        Dim textBoxes = From text In grpCollege.Controls
                        Where text.GetType = GetType(TextBox)
                        Select text
        For Each textBox In textBoxes
            textBox.Enabled = Not textBox.Enabled
        Next
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: flipBtnSaveCancelShow                   -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine flips the visible property of the save   -
    '- and cancel buttons.                                      -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub flipBtnSaveCancelShow()
        btnSave.Visible = Not btnSave.Visible
        btnCancel.Visible = Not btnCancel.Visible
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: flipBtnNavigation                       -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine flips the enabled and visible properties -
    '- of the navigation buttons.                               -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub flipBtnNavigation()
        btPrevious.Enabled = Not btPrevious.Enabled
        btnFirst.Enabled = Not btnFirst.Enabled
        btnAdd.Enabled = Not btnAdd.Enabled
        btnDelete.Enabled = Not btnDelete.Enabled
        btnUpdate.Enabled = Not btnUpdate.Enabled
        btnLast.Enabled = Not btnLast.Enabled
        btnNext.Enabled = Not btnNext.Enabled
        btPrevious.Visible = Not btPrevious.Visible
        btnFirst.Visible = Not btnFirst.Visible
        btnAdd.Visible = Not btnAdd.Visible
        btnDelete.Visible = Not btnDelete.Visible
        btnUpdate.Visible = Not btnUpdate.Visible
        btnLast.Visible = Not btnLast.Visible
        btnNext.Visible = Not btnNext.Visible
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: btnDegreeUpdate_Click                   -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine updates the database with the current    -
    '- college record.                                          -   
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- sender - The object that called the subroutine           -
    '- e - The event arguments                                  -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- cmdBuilder - The command builder object                  -
    '------------------------------------------------------------
    Private Sub btnDegreeUpdate_Click(sender As Object, e As EventArgs)
        Dim cmdBuilder As SqlCommandBuilder
        cmdBuilder = New SqlCommandBuilder(DBAdaptDegrees)
        DBAdaptDegrees.InsertCommand = cmdBuilder.GetInsertCommand
        BindingContext(dsDegrees, "Degrees").EndCurrentEdit()
        sqlConn.Open()
        DBAdaptDegrees.Update(dsDegrees, "Degrees")
        sqlConn.Close()
        dsDegrees.AcceptChanges()
    End Sub

    '------------------------------------------------------------
    '- Subprogram Name: dvgDegreeRefresh                        -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subroutine changes the data source of the data grid -
    '- view to the degrees table.                               -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- strSql - The SQL query string                            -
    '------------------------------------------------------------
    Private Sub dvgDegreeRefresh() Handles txtID.TextChanged
        If txtID.Text IsNot "" Then
            Dim strSql As String
            strSql = "select * from degrees where collegetuid = " & txtID.Text
            dsDegrees.Clear()
            dsDegrees.AcceptChanges()
            DBAdaptDegrees = New SqlDataAdapter(strSql, strConnString)
            DBAdaptDegrees.Fill(dsDegrees, "degrees")
            dvgDegrees.DataSource = dsDegrees.Tables("Degrees")
        End If
    End Sub

    '------------------------------------------------------------
    '- Function Name: GetNextAvailableID                        -
    '------------------------------------------------------------
    '- Written By: Justin T. Kruskie                            -
    '- Written On: March 25, 2023                               -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This function returns the next available ID for the      -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Returns:                                                 -
    '- Integer - The next available ID                          -
    '------------------------------------------------------------
    Private Function GetNextAvailableID() As Integer
        Dim nextID As Integer
        Dim cmd As New SqlCommand("SELECT MAX(Id) + 1 FROM Colleges", sqlConn)

        sqlConn.Open()
        Dim result As Object = cmd.ExecuteScalar()
        If IsDBNull(result) Then
            nextID = 1
        Else
            nextID = Convert.ToInt32(result)
        End If
        sqlConn.Close()

        Return nextID
    End Function

End Class
