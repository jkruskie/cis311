﻿Public Class DiseaseRecord
    Public Property strPatientId As String
    Public Property strPatientFirstName As String
    Public Property strPatientLastName As String
    Public Property dateVisitDate As Date
    Public Property strDiseaseClassification As String
End Class
