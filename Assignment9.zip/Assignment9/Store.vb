﻿Public Class Store
    Public intStoreNumber As Integer
    Public intJanuarySales As Integer
    Public intFebruarySales As Integer
    Public intMarchSales As Integer
    Public intAprilSales As Integer
    Public intMaySales As Integer
    Public intJuneSales As Integer
    Public intJulySales As Integer
    Public intAugustSales As Integer
    Public intSeptemberSales As Integer
    Public intOctoberSales As Integer
    Public intNovemberSales As Integer
    Public intDecemberSales As Integer
    Public dblPreviousSalesTotal As Double

    ' Constructor using an array of strings
    Public Sub New(lineArray As String())
        ' Assign the values from the array to the properties
        intStoreNumber = lineArray(0)
        intJanuarySales = lineArray(1)
        intFebruarySales = lineArray(2)
        intMarchSales = lineArray(3)
        intAprilSales = lineArray(4)
        intMaySales = lineArray(5)
        intJuneSales = lineArray(6)
        intJulySales = lineArray(7)
        intAugustSales = lineArray(8)
        intSeptemberSales = lineArray(9)
        intOctoberSales = lineArray(10)
        intNovemberSales = lineArray(11)
        intDecemberSales = lineArray(12)
        dblPreviousSalesTotal = lineArray(13)
    End Sub

End Class