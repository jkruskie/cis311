﻿Imports System.IO
Imports Microsoft.Office.Interop

'------------------------------------------------------------
'-                File Name : Module1.vb                    - 
'-                Part of Project: Assignment9              -
'------------------------------------------------------------
'-                Written By: Justin T. Kruskie             -
'-                Written On: March 30, 2023                -
'------------------------------------------------------------
'- File Purpose:                                            -
'- This file contains the main application driver, where the-
'- user can decide to use the default file or enter a new   -
'- file name. It will then read the file and create a       -
'- collection of stores. It will then create an excel file  -
'- and display the data to the user.                        -
'------------------------------------------------------------
'- Program Purpose:                                         -
'-                                                          -
'- This program will create an excel file with the data     -
'- from the file. It will then display the data to the user.-
'------------------------------------------------------------
'- Global Variable Dictionary (alphabetically):             -
'- Excel - Excel application                                -
'- StoreFile - Store file name                              -
'- Stores - Collection of stores                            -
'------------------------------------------------------------

Module Module1
    ' Collection of stores
    Public Stores As New Collection
    ' Store file
    Public StoreFile As String = "Stores.txt"
    ' Excel
    Public Excel As New Excel.Application

    '------------------------------------------------------------
    '-                Subprogram Name: Main                     -
    '------------------------------------------------------------
    '-                Written By: Justin T. Kruskie             -
    '-                Written On: March 30, 2023                -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subprogram is the main application driver. It will  -
    '- ask the user if they want to use the default file or     -
    '- enter a new file name. It will then read the file and    -
    '- create a collection of stores. It will then create an    -
    '- excel file and display the data to the user.            -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- (none)                                                   -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- fileExists - Boolean to check if file exists             -
    '- fileName - File name                                     -
    '------------------------------------------------------------
    Sub Main()
        ' Ask user to use default file or enter a new file
        Console.WriteLine("Use default file? (Y/N)")

        ' If user enters Y, use default file
        If Console.ReadLine().ToUpper() = "Y" Then
            ' Read the default file
            ReadFile(StoreFile)
        Else
            ' While loop to ask user for a file name
            ' and check if it exists. 
            ' If it doesn't exist, ask again.
            Dim fileExists As Boolean = False

            While Not fileExists
                Console.WriteLine("Enter a file name: ")
                Dim fileName As String = Console.ReadLine()

                If File.Exists(fileName) Then
                    fileExists = True
                    ReadFile(fileName)
                Else
                    Console.WriteLine("File does not exist.")
                End If
            End While
        End If

        ' Excel 
        Excel = New Excel.Application()

        ' Create a new workbook
        Dim workbook As Excel.Workbook = Excel.Workbooks.Add()

        ' Create a new worksheet
        Dim worksheet As Excel.Worksheet = workbook.Worksheets.Add()

        ' Set the column headers
        SetHeaders(worksheet)

        ' Loop through the stores and write the data to the worksheet
        SetData(worksheet)

        ' Display the worksheet
        Excel.Visible = True

        ' Ask user to exit 
        Console.WriteLine("Press any key to exit.")
        Console.ReadKey()

        ' Clean up
        workbook.Close()

        ' Exit
        End
    End Sub

    '------------------------------------------------------------
    '-                Subprogram Name: ReadFile                 -
    '------------------------------------------------------------
    '-                Written By: Justin T. Kruskie             -
    '-                Written On: March 30, 2023                -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subprogram will read the file and create a          -
    '- collection of stores.                                    -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- worksheet - Excel worksheet                              -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- row - Row number                                         -
    '- store - Store object                                     -
    '------------------------------------------------------------
    Private Sub SetData(worksheet As Excel.Worksheet)
        ' Set the first row
        Dim row As Integer = 2

        ' Loop through the stores and write the data to the worksheet
        ' and set the formulas to calculate the values
        For Each store As Store In Stores
            ' Store Number
            worksheet.Cells(row, 1) = store.intStoreNumber
            ' January
            worksheet.Cells(row, 2) = store.intJanuarySales
            ' February
            worksheet.Cells(row, 3) = store.intFebruarySales
            ' March
            worksheet.Cells(row, 4) = store.intMarchSales
            ' April
            worksheet.Cells(row, 5) = store.intAprilSales
            ' May
            worksheet.Cells(row, 6) = store.intMarchSales
            ' June
            worksheet.Cells(row, 7) = store.intJuneSales
            ' July
            worksheet.Cells(row, 8) = store.intJulySales
            ' August
            worksheet.Cells(row, 9) = store.intAugustSales
            ' September
            worksheet.Cells(row, 10) = store.intSeptemberSales
            ' October
            worksheet.Cells(row, 11) = store.intOctoberSales
            ' November
            worksheet.Cells(row, 12) = store.intNovemberSales
            ' December
            worksheet.Cells(row, 13) = store.intDecemberSales
            ' Average
            worksheet.Cells(row, 14) = "=AVERAGE(B" & row & ":M" & row & ")"
            ' Current Total
            worksheet.Cells(row, 15) = "=SUM(B" & row & ":M" & row & ")"
            ' Previous Total
            worksheet.Cells(row, 16) = store.dblPreviousSalesTotal
            ' Sales Variance (current / previous
            worksheet.Cells(row, 17) = "=IFERROR((O" & row & "/P" & row & "),0)"
            ' Blank
            worksheet.Cells(row, 18) = ""
            ' Sum Jan-Mar
            worksheet.Cells(row, 19) = "=SUM(B" & row & ":D" & row & ")"
            ' Sum Apr-Jun
            worksheet.Cells(row, 20) = "=SUM(E" & row & ":G" & row & ")"
            ' Sum Jul-Sep
            worksheet.Cells(row, 21) = "=SUM(H" & row & ":J" & row & ")"
            ' Sum Oct-Dec
            worksheet.Cells(row, 22) = "=SUM(K" & row & ":M" & row & ")"
            ' Increment the row
            row += 1
        Next

    End Sub

    '------------------------------------------------------------
    '-                Subprogram Name: SetHeaders               -
    '------------------------------------------------------------
    '-                Written By: Justin T. Kruskie             -
    '-                Written On: March 30, 2023                -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subprogram will set the column headers.             -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- worksheet - Excel worksheet                              -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '------------------------------------------------------------
    '- (none)                                                   -
    '------------------------------------------------------------
    Private Sub SetHeaders(worksheet As Excel.Worksheet)
        ' Set the column headers
        ' Store Class properties
        worksheet.Cells(1, 1) = "Store Number"
        worksheet.Cells(1, 2) = "January"
        worksheet.Cells(1, 3) = "February"
        worksheet.Cells(1, 4) = "March"
        worksheet.Cells(1, 5) = "April"
        worksheet.Cells(1, 6) = "May"
        worksheet.Cells(1, 7) = "June"
        worksheet.Cells(1, 8) = "July"
        worksheet.Cells(1, 9) = "August"
        worksheet.Cells(1, 10) = "September"
        worksheet.Cells(1, 11) = "October"
        worksheet.Cells(1, 12) = "November"
        worksheet.Cells(1, 13) = "December"
        ' Average
        worksheet.Cells(1, 14) = "Average"
        ' Current Total
        worksheet.Cells(1, 15) = "Current Total"
        ' Previous Total
        worksheet.Cells(1, 16) = "Previous Total"
        ' Sales Variance
        worksheet.Cells(1, 17) = "Sales Variance"
        ' Blank
        worksheet.Cells(1, 28) = ""
        ' Sum Jan-Mar
        worksheet.Cells(1, 19) = "Jan-Mar"
        ' Sum Apr-Jun
        worksheet.Cells(1, 20) = "Apr-Jun"
        ' Sum Jul-Sep
        worksheet.Cells(1, 21) = "Jul-Sep"
        ' Sum Oct-Dec
        worksheet.Cells(1, 22) = "Oct-Dec"
    End Sub

    '------------------------------------------------------------
    '-                Subprogram Name: ReadFile                -
    '------------------------------------------------------------
    '-                Written By: Justin T. Kruskie             -
    '-                Written On: March 30, 2023                -
    '------------------------------------------------------------
    '- Subprogram Purpose:                                      -
    '-                                                          -
    '- This subprogram will read the file and create a new      -
    '- store object for each line.                              -
    '------------------------------------------------------------
    '- Parameter Dictionary (in parameter order):               -
    '- fileName - File name                                     -
    '------------------------------------------------------------
    '- Local Variable Dictionary (alphabetically):              -
    '- fileReader - File reader                                 -
    '- line - Current line                                      -
    '- lineArray - Array of line values                         -
    '- store - Store object                                     -
    '------------------------------------------------------------
    Private Sub ReadFile(fileName As String)
        ' Read the file
        Dim fileReader As New StreamReader(fileName)
        ' Loop through each line and create a new store
        ' and add it to the collection
        While Not fileReader.EndOfStream
            ' Get the current line
            Dim line As String = fileReader.ReadLine()
            ' Split the line using the comma as a delimiter
            Dim lineArray As String() = line.Split(",")
            ' Create a new store
            Dim store As New Store(lineArray)
            Stores.Add(store)
        End While

        ' Console log the number of stores
        Console.WriteLine("Number of stores: " & Stores.Count)
    End Sub
End Module
